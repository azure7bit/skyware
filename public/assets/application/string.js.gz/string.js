String.prototype.capitalize = function() {
  return this.charAt(0).toUpperCase() + this.slice(1);
};

String.prototype.humanize = function() {
   return this.replace('_', ' ').capitalize();
};
